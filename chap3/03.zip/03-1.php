<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>ログイン</title>
<link rel="stylesheet" href="css/foo.css">
</head>
<body>
<h1>ログイン</h1>
<form method="GET" action="03-8.php">
    ID<input type="text" name="login_id"><br>
パスワード<input type="text" name="login_pass"><br>
<input type="submit" value="ログイン">
</form>
</body></html>