<?php
define("DB_SERVER", "localhost");     // サーバ
define("DB_NAME", "jikkyo_pension");  // データベース
define("DB_USER", "jikkyo");          // ユーザ
define("DB_PASS", "pass");            // パスワード
?>