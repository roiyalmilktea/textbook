  <nav id="menu">
    <ul>
      <li><a href="./index.php">ホーム</a></li>
      <li><a href="./roomList.php">お部屋紹介</a></li>
      <li><a href="./reserveDay.php">ご予約</a></li>
      <li><a href="./rental.php">レンタル</a><li>
    </ul>
  </nav>
