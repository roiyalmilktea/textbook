<!DOCTYPE html>
<html>
	<head>
		<title>resist</title>
	</head>
	<body>
		
	</body>
</html>
<?php 
  
  echo "認証しました";
?>
